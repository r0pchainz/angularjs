import { VoterComponent } from './voter.component';

describe('VoterComponent', () => {

  beforeEach(() => {
  });

  it('', () => {
  });
});
